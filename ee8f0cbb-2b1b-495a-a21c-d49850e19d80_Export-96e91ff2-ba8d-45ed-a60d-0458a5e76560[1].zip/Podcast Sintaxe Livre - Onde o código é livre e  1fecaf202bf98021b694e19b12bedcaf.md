# Podcast Sintaxe Livre - Onde o código é livre e a ideia também

# Episódio

[db_espisodes](db_espisodes%201fecaf202bf981c5b082c3b4d6829b62.csv)

# Transcrição

[Sem título](Sem%20ti%CC%81tulo%201fecaf202bf981eaa03bf11e1366177a.csv)