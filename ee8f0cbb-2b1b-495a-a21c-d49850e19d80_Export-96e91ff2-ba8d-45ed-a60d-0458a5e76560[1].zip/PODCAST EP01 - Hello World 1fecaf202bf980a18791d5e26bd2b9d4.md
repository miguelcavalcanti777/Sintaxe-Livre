# PODCAST EP01 - Hello World

Temas: Frontend, Linguagem C, Tecnologia
db_espisodes: PODCAST EP01 - Hello World (PODCAST%20EP01%20-%20Hello%20World%201fecaf202bf98133ac87e52c5fe9d90a.md)

[PODCAST EP01 - Hello World](PODCAST%20EP01%20-%20Hello%20World%201fecaf202bf9805dbab5e7c70ff18295.md)