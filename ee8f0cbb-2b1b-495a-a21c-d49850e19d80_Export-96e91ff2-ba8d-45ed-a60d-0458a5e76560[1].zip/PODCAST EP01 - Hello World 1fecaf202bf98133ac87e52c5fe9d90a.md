# PODCAST EP01 - Hello World

Podcast: PODCAST EP01 - Hello World (PODCAST%20EP01%20-%20Hello%20World%201fecaf202bf980a18791d5e26bd2b9d4.md)
Created: 25 de maio de 2025 02:15
Tags: Linguagem C, frontend, tecnologia
Files & media: create_a_volleyball_player_character_with_a_microphone_on_a_table_like_a_podcast_retro_style_isometric_cube_game_style_low_resolution_down_angle_game_boy_colors_8_bits_retro_sprites_--ar_1_1_--v_5.2.png, 202505250632_(online-audio-converter.com).mp3